from setuptools import setup, find_packages
import os

long_description = "Prince: Principal Component Analysis and Factor Analysis library"
readme_path = "README.md"
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as fh:
        long_description = fh.read()

setup(
    name="prince",
    version="0.16.6",
    author="",
    description="A Python library for factor analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/paulhendricks/prince",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
    install_requires=[
        "numpy",
        "pandas",
        "scikit-learn",
        "scipy",
    ],
    include_package_data=True,
)
